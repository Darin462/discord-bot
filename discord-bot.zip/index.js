require("dotenv").config();
const { Client, GatewayIntentBits } = require("discord.js");
const { joinVoiceChannel, createAudioPlayer, createAudioResource, AudioPlayerStatus, VoiceConnectionStatus } = require("@discordjs/voice");
const { spawn } = require("child_process");
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
    ]
});
let currentConnection = null;
let currentPlayer = null;
client.once("ready", () => {
    console.log(`✅ BeatBuddy is online as ${client.user.tag}`);
});
client.on("messageCreate", async (message) => {
    if (message.author.bot) return;
    const args = message.content.split(" ");
    const command = args.shift().toLowerCase();
    if (command === "/play") {
        if (!args[0]) return message.reply("❌ You need to provide a YouTube link!");
        if (!message.member.voice.channel) return message.reply("❌ You need to join a voice channel first!");
        const voiceChannel = message.member.voice.channel;
        // Join the voice channel
        currentConnection = joinVoiceChannel({
            channelId: voiceChannel.id,
            guildId: voiceChannel.guild.id,
            adapterCreator: voiceChannel.guild.voiceAdapterCreator,
            selfDeaf: false,
        });
        console.log("Bot joined voice channel:", voiceChannel.name);
        currentConnection.on(VoiceConnectionStatus.Ready, () => {
            console.log("Voice connection ready");
        });
        // Create audio player
        currentPlayer = createAudioPlayer();
        currentConnection.subscribe(currentPlayer);
        console.log("Player subscribed to connection");
        // Stream audio with yt-dlp
        const ytDlp = spawn("yt-dlp", ["-f", "bestaudio", "-o", "-", args[0]]);
        console.log("Fetching audio with yt-dlp...");
        // Create a single audio resource from the yt-dlp stream
        const resource = createAudioResource(ytDlp.stdout, { inlineVolume: true });
        resource.volume.setVolume(0.5); // Set volume to 50%
        currentPlayer.play(resource);
        console.log("Playing audio resource");
        message.reply(`🎵 Playing: ${args[0]}`);
        ytDlp.stderr.on("data", (data) => {
            console.error(`yt-dlp stderr: ${data}`);
        });
        ytDlp.on("close", (code) => {
            console.log(`yt-dlp closed with code ${code}`);
            if (code !== 0) message.reply("❌ Failed to play audio. Check the URL or try again.");
        });
        currentPlayer.on("error", (error) => {
            console.error("Player error:", error.message);
            message.reply("❌ Error playing audio.");
            if (currentConnection) currentConnection.destroy();
            currentConnection = null;
            currentPlayer = null;
        });
        currentPlayer.on(AudioPlayerStatus.Idle, () => {
            console.log("Audio finished, disconnecting...");
            if (currentConnection) currentConnection.destroy();
            currentConnection = null;
            currentPlayer = null;
        });
    }
    if (command === ".") {
        if (!currentConnection) return message.reply("❌ I'm not in a voice channel!");
        if (currentPlayer) currentPlayer.stop();
        currentConnection.destroy();
        currentConnection = null;
        currentPlayer = null;
        message.reply("👋 BeatBuddy has left the channel");
        console.log("Bot left the voice channel");
    }
});
client.login(process.env.TOKEN);
 
